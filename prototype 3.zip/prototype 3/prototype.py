from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors, re

app = Flask(__name__)
app.secret_key = '255'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'flask_accounts'

mysql = MySQL(app)

@app.route('/')
def click_here():
    return render_template('directory.html')

@app.route('/main')
def main_page():
    return render_template('main.html')


@app.route('/about')
def about_page():
    return render_template('about.html')


@app.route('/animals')
def animals_page():
    return render_template('animals.html')


@app.route('/bookings')
def bookings_page():
    return render_template('bookings.html')


@app.route('/bookings/zoo')
def booking_zoo_page():
    return render_template('booking_zoo.html')


@app.route('/bookings/hotel')
def booking_hotel_page():
    return render_template('booking_hotel.html')


@app.route('/hotel')
def hotel_page():
    return render_template('hotel.html')

@app.route('/payment')
def payment_page():
    return render_template('payment.html')

@app.route('/settings')
def settings_page():
    return render_template('settings.html')

@app.route('/rules')
def rules_page():
    return render_template('rules.html')

if __name__ == '__main__':
    app.run(debug=True)
