import sqlite3

conn = sqlite3.connect('flask_accounts')

cur = conn.cursor()

# cur.execute("drop table if exists login")

# cur.execute("CREATE TABLE IF NOT EXISTS login (id INTEGER PRIMARY KEY NOT NULL, username VARCHAR NOT NULL, email VARCHAR NOT NULL, password VARCHAR NOT NULL)")

cur.execute("SELECT * FROM login")

conn.commit()

conn.close()